document.addEventListener('DOMContentLoaded', () => {
    const redSlider = document.getElementById('red');
    const greenSlider = document.getElementById('green');
    const blueSlider = document.getElementById('blue');

    const redValueSpan = document.getElementById('red-value');
    const greenValueSpan = document.getElementById('green-value');
    const blueValueSpan = document.getElementById('blue-value');

    const colorBox = document.getElementById('color-box');
    const hexCodeParagraph = document.getElementById('hex-code');
    const predefinedColorsContainer = document.getElementById('predefined-colors');

    // Predefined colors (name and hex code)
    const predefinedColors = [
        { name: 'Red', hex: '#FF0000' },
        { name: 'Green', hex: '#008000' },
        { name: 'Blue', hex: '#0000FF' },
        { name: 'Yellow', hex: '#FFFF00' },
        { name: 'Cyan', hex: '#00FFFF' },
        { name: 'Magenta', hex: '#FF00FF' },
        { name: 'Black', hex: '#000000' },
        { name: 'White', hex: '#FFFFFF' },
        { name: 'Orange', hex: '#FFA500' },
        { name: 'Purple', hex: '#800080' },
        { name: 'Gray', hex: '#808080' }
    ];

    function updateColor() {
        const red = redSlider.value;
        const green = greenSlider.value;
        const blue = blueSlider.value;

        // Atualiza os valores numéricos ao lado dos sliders
        redValueSpan.textContent = red;
        greenValueSpan.textContent = green;
        blueValueSpan.textContent = blue;

        // Converte os valores RGB para hexadecimal
        const hexRed = parseInt(red).toString(16).padStart(2, '0');
        const hexGreen = parseInt(green).toString(16).padStart(2, '0');
        const hexBlue = parseInt(blue).toString(16).padStart(2, '0');

        const hexColor = `#${hexRed}${hexGreen}${hexBlue}`.toUpperCase();

        // Atualiza a cor da caixa de visualização
        colorBox.style.backgroundColor = `rgb(${red}, ${green}, ${blue})`;

        // Atualiza o código hexadecimal
        hexCodeParagraph.textContent = hexColor;
    }

    function copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            alert(`"${text}" copiado para a área de transferência!`);
        }).catch(err => {
            console.error('Falha ao copiar texto: ', err);
        });
    }

    function hexToRgb(hex) {
        const r = parseInt(hex.substring(1, 3), 16);
        const g = parseInt(hex.substring(3, 5), 16);
        const b = parseInt(hex.substring(5, 7), 16);
        return { r, g, b };
    }

    function loadPredefinedColors() {
        predefinedColors.forEach(color => {
            const colorItem = document.createElement('div');
            colorItem.classList.add('predefined-color-item');

            const colorBoxElem = document.createElement('div');
            colorBoxElem.classList.add('predefined-color-box');
            colorBoxElem.style.backgroundColor = color.hex;
            colorBoxElem.title = color.name; // Tooltip

            // Add click event to load color into sliders
            colorBoxElem.addEventListener('click', () => {
                const rgb = hexToRgb(color.hex);
                redSlider.value = rgb.r;
                greenSlider.value = rgb.g;
                blueSlider.value = rgb.b;
                updateColor();
            });

            const colorInfo = document.createElement('div');
            colorInfo.classList.add('predefined-color-info');

            const colorHexSpan = document.createElement('span');
            colorHexSpan.classList.add('predefined-color-hex');
            colorHexSpan.textContent = color.hex;

            const copyButton = document.createElement('button');
            copyButton.classList.add('copy-button');
            copyButton.textContent = 'Copiar';
            copyButton.addEventListener('click', () => copyToClipboard(color.hex));

            colorInfo.appendChild(colorHexSpan);
            colorInfo.appendChild(copyButton);

            colorItem.appendChild(colorBoxElem);
            colorItem.appendChild(colorInfo);

            predefinedColorsContainer.appendChild(colorItem);
        });
    }

    // Adiciona event listeners para cada slider
    redSlider.addEventListener('input', updateColor);
    greenSlider.addEventListener('input', updateColor);
    blueSlider.addEventListener('input', updateColor);

    // Inicializa a cor quando a página carrega
    updateColor();
    loadPredefinedColors();
});