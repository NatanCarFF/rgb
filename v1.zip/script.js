document.addEventListener('DOMContentLoaded', () => {
    const redSlider = document.getElementById('red');
    const greenSlider = document.getElementById('green');
    const blueSlider = document.getElementById('blue');

    const redValueSpan = document.getElementById('red-value');
    const greenValueSpan = document.getElementById('green-value');
    const blueValueSpan = document.getElementById('blue-value');

    const colorBox = document.getElementById('color-box');
    const hexCodeParagraph = document.getElementById('hex-code');

    function updateColor() {
        const red = redSlider.value;
        const green = greenSlider.value;
        const blue = blueSlider.value;

        // Atualiza os valores numéricos ao lado dos sliders
        redValueSpan.textContent = red;
        greenValueSpan.textContent = green;
        blueValueSpan.textContent = blue;

        // Converte os valores RGB para hexadecimal
        const hexRed = parseInt(red).toString(16).padStart(2, '0');
        const hexGreen = parseInt(green).toString(16).padStart(2, '0');
        const hexBlue = parseInt(blue).toString(16).padStart(2, '0');

        const hexColor = `#${hexRed}${hexGreen}${hexBlue}`.toUpperCase();

        // Atualiza a cor da caixa de visualização
        colorBox.style.backgroundColor = `rgb(${red}, ${green}, ${blue})`;

        // Atualiza o código hexadecimal
        hexCodeParagraph.textContent = hexColor;
    }

    // Adiciona event listeners para cada slider
    redSlider.addEventListener('input', updateColor);
    greenSlider.addEventListener('input', updateColor);
    blueSlider.addEventListener('input', updateColor);

    // Inicializa a cor quando a página carrega
    updateColor();
});